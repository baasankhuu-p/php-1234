<?php
require ROOT . '/pages/user/header.php';
?>
<h4 class="mb-0 font-size-18">Шинээр орлого бүртгэх</h4>
<?php
require ROOT . '/pages/user/footer.php';