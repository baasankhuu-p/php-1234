<?php
//Үндсэн тохиргоо
const DOMAIN = 'php-learn.com';
//Өгөгдлийн сангийн тогтмол
const DB_HOST = '127.0.0.1';
const DB_NAME = 'php_learn';
const DB_USER = 'root';
const DB_PASSWORD = '';
